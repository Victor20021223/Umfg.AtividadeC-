﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite seu nome: ");
        string nomeUsuario = Console.ReadLine();

        string nomeLowerCase = nomeUsuario.ToLower();

        int contadorConsoantes = 0;

        foreach (char caractere in nomeLowerCase)
        {
            if (IsConsoante(caractere))
            {
                contadorConsoantes++;
            }
        }

        Console.WriteLine($"O nome {nomeUsuario} possui {contadorConsoantes} consoantes.");
    }

    static bool IsConsoante(char c)
    {
        return char.IsLetter(c) && !"aeiou".Contains(c);
    }
}
