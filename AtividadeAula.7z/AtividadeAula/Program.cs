﻿using System;

class Program
{
    static void Main()
    { 
        Console.Write("Digite o valor para conversão : ");
        double valorReal = Convert.ToDouble(Console.ReadLine());

        double taxaCambio = 0.193259;
        double valorDolar = valorReal * taxaCambio;

        Console.WriteLine($"O Valor {valorReal} em Reais equivalem a {valorDolar} em Dólares");
    }
}
