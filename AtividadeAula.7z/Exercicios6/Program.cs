﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite seu nome: ");
        string nomeUsuario = Console.ReadLine();

        string nomeLowerCase = nomeUsuario.ToLower();

        int contadorVogais = 0;

        foreach (char caractere in nomeLowerCase)
        {
            if (IsVogal(caractere))
            {
                contadorVogais++;
            }
        }

        Console.WriteLine($"O nome {nomeUsuario} possui {contadorVogais} vogais.");
    }

    static bool IsVogal(char c)
    {
        return "aeiou".Contains(c);
    }
}
