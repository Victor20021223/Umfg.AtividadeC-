﻿// See htusing System;

class Program
{
    static void Main()
    { 
        Console.Write("Digite o valor para conversão : ");
        double valorDolar = Convert.ToDouble(Console.ReadLine());

        double taxaCambio = 5.22;
        double valorReal = valorDolar * taxaCambio;

        Console.WriteLine($"O Valor {valorDolar} em Dólares equivalem a {valorReal} em Reais");
    }
}
